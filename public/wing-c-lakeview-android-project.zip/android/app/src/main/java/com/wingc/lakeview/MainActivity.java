package com.wingc.lakeview;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
